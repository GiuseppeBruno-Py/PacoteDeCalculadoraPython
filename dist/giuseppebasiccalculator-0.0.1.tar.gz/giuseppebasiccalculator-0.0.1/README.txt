Isso é uma simples calculadora que pega dois números e faz a soma, subtração, multiplicação ou divisão
